/****
 * Title: Project 1 Reservation System
 * Course: Computational Problem Solving II (CPET-321.01.2211)
 * Developer: Elyse Amorati
 * Date: Oct 8, 2021
 * Description: [SeatNode.h]Using supporting files, forms a reservation system for quidditch team
 ***/


#ifndef SEATNODE_H_
#define SEATNODE_H_

#include <string>
#include "Passenger.h"
using namespace std;


class SeatNode {
public:
	// Constructors and Destructor
	SeatNode();
	~SeatNode();
	SeatNode(string car, string type, int cost, Passenger d);

	// Get functions
    string GetCar();
    string GetType();
    string isTaken();
    string GetReservation();
    Passenger GetPassenger();
    Passenger GetDriver();
    int GetCost();

    // Add and Remove all information from SeatNode
    void AssignSeat(Passenger pass, string r);
    void DeleteSeat();

    // Get location pointed by nextNodePtr
    SeatNode* GetNext();
    // Add SeatNode to the end of linked list
    void InsertAfter(SeatNode* nodeLoc);

    // Print function
    string PrintPassenger();
    void PrintContactNode(); // to be deleted

 private:
    SeatNode* nextNodePtr;
    string car, type, reservation, taken = "Unassigned";
	int cost;
	Passenger p, driver;
};

#endif /* SEATNODE_H_ */
