/****
 * Title: Project 1 Reservation System
 * Course: Computational Problem Solving II (CPET-321.01.2211)
 * Developer: Elyse Amorati
 * Date: Oct 8, 2021
 * Description: [Reservation.cpp]Using supporting files, forms a reservation system for quidditch team
 ***/

#include "Reservation.h"
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

 //Name: ToUpper()
 //Input: string
 //Output: same string but uppercase
 //Purpose: Converts string to all uppercase
string Reservation::ToUpper(string s) {
	string final;
	char temp;
	// Loops through string s and creates new string of each char that is uppercase
	for (unsigned int i = 0; i < s.size(); i++) {
		temp = (char) toupper(s.at(i));
		final.push_back(temp);
	}
	return final;
}

 //Name: PrintMenu()
 //Input: n/a
 //Output: menu options that user can navigate with
 //Purpose: Prints Menu and gets user response
char Reservation::PrintMenu() {
	char userInput;
	cout << endl << "MENU" << endl;
	cout << "   Create a Reservation:        enter '1'" << endl;
	cout << "   Modify a Reservation:        enter '2'" << endl;
	cout << "   Delete a Reservation:        enter '3'" << endl;
	cout << "   Display vehicles:            enter '4'" << endl;
	cout << "   Print vehicle assignments:   enter '5'" << endl;
	cout << "   Print Reservations:          enter '6'" << endl;
	cout << "'0' to exit program             ";

	cin >> userInput;
	return userInput;
}

// NEEDS DISPLAY
 //Name: CreateReservations()
 //Input: passenger vector and two nodes
 //Output: a reservation is made and stored in the linked list
 //Purpose: Creates a Reservation
int Reservation::CreateReservations(vector<Passenger>& passengers, SeatNode* headNode, SeatNode* lastNode) {
	string userInput, userType, userCar, tempRes, err;
	unsigned int pos = 0, i, loops = 1;
	SeatNode* currNode;
	Passenger tempP;

	// Prompt for user input
	cout << "Enter player name: ";
	cin.ignore();
	getline(cin, userInput);

	// *** Confirm input name is valid ***
	// Iterate through vector of passengers to find Passenger
	try {
		for(i = 0; i < passengers.size(); i++) {
			// Check if passenger name is equal to input name
			if (ToUpper(passengers.at(i).GetName()) == ToUpper(userInput)) {
				tempP = passengers.at(i);						// Saves Passenger info
				break;
			}
		}
		if (tempP.GetCredits() == -1) {
			throw err;											// Throws error if no matching passenger is found
		}
	} catch(string& err) {
		cout << " *** Exception: Player not found in roster" << endl;
		return 0;
	}

	// *** Confirm Passenger has more than 0 credits ***
	try {
		if (tempP.GetCredits() == 0) {
			throw err;
		}
	} catch(string& err) {
		cout << " *** Exception: Player has 0 credits" << endl;
		return 0;
	}

	// *** Print that Passenger was found and Display all seats ***
	cout << "Player found with " << tempP.GetCredits() << " credits" << endl;


	DisplayVehicles(headNode, lastNode);


	// *** Assign seat based on input Type or input Car and Type ***
	// while allows user to input seat until input is valid
	while (loops == 1) {

		// Prompt for user input
		cout << endl << "Enter seat ('type' or 'type, car'): ";
		getline(cin, userInput);
		pos = userInput.find(',');

		// Reset currNode to first node
		currNode = headNode->GetNext();

		// Checks if user input 'type' or 'type, car'
		if (userInput.find(',') != string::npos) {

			// *** User input type, car ***
			try {
				userType = ToUpper(userInput.substr(0, pos));							// Parse string, save Type
				userCar = ToUpper(userInput.substr(pos+2, userInput.back()));			// Parse string, save Car

				// Iterates through linked list
				while(currNode != nullptr) {
					// Check if seat a) is in correct car b) has correct type c) is unassigned and d) passenger can afford it
					if (ToUpper(currNode->GetCar()) == userCar && ToUpper(currNode->GetType()) == userType &&
							currNode->isTaken() == "Unassigned" && tempP.GetCredits() >= currNode->GetCost()) {

						cout << "Car and seat found!" << endl;
						tempRes = tempP.GetIndex();										// Creates Reservation number
						tempP.SetCredits(tempP.GetCredits() - currNode->GetCost());		// Removes Credits from passenger
						passengers.at(i) = tempP;										// Inserts altered Passenger back into vector

						cout << "Seat assigned to " << tempP.GetName() << " with reservation number " << tempRes << endl;
						currNode->AssignSeat(tempP, tempRes);
						return 0;
					} else {
						currNode = currNode->GetNext();									// Iterates to next node
					}
				}
				throw err;																// Throws error if no match is found
			} catch (string& err) {
				cout << " *** Exception: Unable to reserve seat" << endl;
			}

		} else {

			// *** User input only type ***
			try {
				userType = ToUpper(userInput);											// Saves Type
				// Iterates through linked list
				while(currNode != nullptr) {
					// Check if seat a) has correct type b) is unassigned and c) passenger can afford it
					if (ToUpper(currNode->GetType()) == userType && currNode->isTaken() == "Unassigned"
							&& tempP.GetCredits() >= currNode->GetCost()) {

						cout << "Seat found!" << endl;
						tempRes = tempP.GetIndex() + 1;										// Creates Reservation number
						tempP.SetCredits(tempP.GetCredits() - currNode->GetCost());		// Removes Credits from passenger
						passengers.at(i) = tempP;										// Inserts altered Passenger back into vector

						cout << "Seat assigned to " << tempP.GetName() << " with reservation number " << tempRes << endl;
						currNode->AssignSeat(tempP, tempRes);							// Assign current Seat to Passenger
						return 0;
					} else {
						currNode = currNode->GetNext();									// Iterates to next node
					}
				}
				throw err;																// Throws error if no match is found
			} catch (string& err) {
				cout << " *** Exception: Unable to reserve seat" << endl;
			}
		}
	}
	return 0;
}

// COMPLETE
 //Name: ModifyReservations(vector<Passenger>& passengers, SeatNode* headNode, SeatNode* lastNode)
 //Input: passenger vector and two nodes 
 //Output: deletes first reservation and makes new reservation
 //Purpose: Modifies a Reservation
int Reservation::ModifyReservations(vector<Passenger>& passengers, SeatNode* headNode, SeatNode* lastNode) {
	string userInput, userType, userCar, tempRes = "-1", err;
	int pos, loops = 1;
	Passenger tempP;
	SeatNode* currNode;

	// Prompt for user input
	cout << "Enter reservation number: ";
	cin.ignore();
	getline(cin, userInput);

	// *** Searches for Reservation number in linked list ***
	try {
		// Set currNode to first node
		currNode = headNode->GetNext();
		// Iterate through linked list
		while(currNode != nullptr) {
			// Checks if input Reservation is a match
			if (currNode->GetReservation() == userInput) {
				cout << "Reservation found!" << endl;
				tempRes = currNode->GetReservation();							// Saves Reservation number
				tempP = currNode->GetPassenger();								// Saves Passenger in seat
				tempP.SetCredits(tempP.GetCredits() + currNode->GetCost()); 	// Gives Passenger back used Credits
				currNode->DeleteSeat();											// Clears all data in seat
				break;
			} else {
				currNode = currNode->GetNext();									// Iterates to next node
			}
		}
		if (tempRes == "-1") {
			throw err;															// Throws error if no match is found
		}
	} catch (string& err) {
		cout << " *** Exception: Invalid reservation number" << endl;
		return 0;
	}

	// *** Prompt for new car and seat ***
	while (loops == 1) {
		cout << endl << "Enter new seat ('type, car'): ";
		getline(cin, userInput);
		pos = userInput.find(',');
		userType = ToUpper(userInput.substr(0, pos));								// Parse string, save type
		userCar = ToUpper(userInput.substr(pos+2, userInput.back()));				// Parse string, save car

		// Searches linked list for open car and seat
		try {
			// Reset currNode to first node
			currNode = headNode->GetNext();
			// Iterate through linked list
			while(currNode != nullptr) {
				// Check if seat a) is in correct car b) has correct type c) is unassigned and d) passenger can afford it
				if (ToUpper(currNode->GetCar()) == userCar && ToUpper(currNode->GetType()) == userType && currNode->isTaken() == "Unassigned"
						&& tempP.GetCredits() >= currNode->GetCost()) {
					tempP.SetCredits(tempP.GetCredits() - currNode->GetCost());		// Remove credits from Passenger
					passengers.at(stoi(tempP.GetIndex())) = tempP;					// Insert altered Passenger back into vector
					cout << "Seat assigned to " << tempP.GetName() << endl;
					currNode->AssignSeat(tempP, tempRes);							// Assign current Seat to Passenger
					return 0;
				} else {
					currNode = currNode->GetNext();									// Iterate to next node
				}
			}
			throw err;																// Throw error if no match is found
		} catch (string& err) {
			cout << " *** Exception: Unable to reserve seat" << endl;
		}
	}
	return 0;
}

// COMPLETE
 //Name: DeleteReservations(vector<Passenger>& passengers, SeatNode* headNode, SeatNode* lastNode)
 //Input: passenger vector, two nodes
 //Output: deallocates reservation data and refunds tokens
 //Purpose: Deletes a Reservation
int Reservation::DeleteReservations(vector<Passenger>& passengers, SeatNode* headNode, SeatNode* lastNode) {
	string userInput, err;
	SeatNode* currNode;
	Passenger tempP;
	int tempC = -1;

	// Prompt for user input
	cout << "Enter reservation number: ";
	cin.ignore();
	getline(cin, userInput);

	// *** Searches for Reservation number in linked list ***
	try {
		// Reset currNode to first node
		currNode = headNode->GetNext();
		// Iterate through linked list
		while(currNode != nullptr) {
			// Checks if input Reservation is a match
			if (currNode->GetReservation() == userInput) {
				tempP = currNode->GetPassenger();				// Saves passenger in seat
				tempC = currNode->GetCost();					// Saves cost of seat

				currNode->DeleteSeat();							// Deletes all seat info
				cout << "Reservation deleted" << endl;

				tempP.SetCredits(tempP.GetCredits() + tempC);	// Give Passenger back used Credits
				passengers.at(stoi(tempP.GetIndex())) = tempP;	// Add fixed Passenger back to vector of passengers

				break;
			} else {
				currNode = currNode->GetNext();					// Iterate to next node
			}
		}
		if (tempC == -1) {
			throw err;											// Throw error if no match is found
		}
	} catch (string& err) {
		cout << " *** Exception: Invalid reservation number" << endl;
		return 0;
	}
	return 0;
}


 //Name: DisplayVehicles()
 //Input: n/a
 //Output: graphical representation of reservation data
 //Purpose: Displays all Vehicles and Seats
int Reservation::DisplayVehicles(SeatNode* headNode, SeatNode* lastNode) {
	string carStr;
	SeatNode* currNode;
	vector<string> cars;
	unsigned int i, j;

	// Reset currNode to the first node
	currNode = headNode->GetNext();

	cout << "\n\nSeat types include front, mid, and back.\n\n";

	// Print out Pickups
	for (i = 0; i < 2; i++) {
		cout << setfill (' ') << setw (16) << currNode->GetCar();
		carStr = ": (x)  ";
		if (currNode->isTaken() == "Unassigned") {
			carStr += "(" + to_string(currNode->GetCost()) + ")";		// If seat is unassigned, print number
		} else {
			carStr += "(-)";											// If seat is assigned, print a taken spot
		}
		currNode = currNode->GetNext();									// Iterates to next node
		cout << carStr << endl << endl;									// Print Pickup info
	}


	// Print out Compacts
	for (i = 0; i < 3; i++) {
		cout << setfill (' ') << setw (16) << currNode->GetCar();
		carStr = ": (x)  ";
		if (currNode->isTaken() == "Unassigned") {
			carStr += "(" + to_string(currNode->GetCost()) + ")\n";				// If seat is unassigned, print number
		} else {
			carStr += "(-)\n";													// If seat is assigned, print a taken spot
		}
		carStr += "                 ";
		currNode = currNode->GetNext();
		for (j = 0; j < 2; j++) {
			if (currNode->isTaken() == "Unassigned") {
				carStr += " (" + to_string(currNode->GetCost()) + ") ";		// If seat is unassigned, print number
			} else {
				carStr += " (-) ";											// If seat is assigned, print a taken spot
			}
			currNode = currNode->GetNext();										// Iterates to next node
		}
		cout << carStr << endl << endl;											// Print Compact info
	}


	// Print out Sedans
	for (i = 0; i < 3; i++) {
		cout << setfill (' ') << setw (16) << currNode->GetCar();
		carStr = ": (x)       ";
		if (currNode->isTaken() == "Unassigned") {
			carStr += "(" + to_string(currNode->GetCost()) + ")\n";				// If seat is unassigned, print number
		} else {
			carStr += "(-)\n";													// If seat is assigned, print a taken spot
		}
		carStr += "                 ";
		currNode = currNode->GetNext();
		for (j = 0; j < 3; j++) {
			if (currNode->isTaken() == "Unassigned") {
				carStr += " (" + to_string(currNode->GetCost()) + ") ";		// If seat is unassigned, print number
			} else {
				carStr += " (-) ";											// If seat is assigned, print a taken spot
			}
			currNode = currNode->GetNext();										// Iterates to next node
		}
		cout << carStr << endl << endl;											// Print Sedans info
	}

	return 0;
}

//COMPLETE
 //Name: PrintVehicles()
 //Input: two nodes
 //Output: txt file with reservation data for a specific vehicle
 //Purpose: Prints the Passengers of a specific vehicle as text and a .txt file
int Reservation::PrintVehicles(SeatNode* headNode, SeatNode* lastNode) {
	string userInput, nameT, err = "0", allInfo, tempStr, prevCar;
	SeatNode* currNode;
	int pos;

	// Prompt for input of a single car
	cout << "Enter car: ";
	cin.ignore();
	getline(cin, userInput);

	// *** Display & Save to .txt Vehicle Info ***
	try {
		// Reset currNode to first node
		currNode = headNode->GetNext();

		// Loop through linked list. If Car matches Input, cout and save info
		while(currNode != nullptr) {
			if (ToUpper(userInput) == currNode->GetCar()) {

				// If First successful iteration, add Car and Driver
				if (err == "0") {
					cout << endl << "   " << currNode->GetCar() << endl;										// Prints car Name
					cout << "DRIVER: " << currNode->GetDriver().GetName() << endl;								// Prints Driver
					allInfo = currNode->GetCar() + "\n" + "DRIVER: " + currNode->GetDriver().GetName() + "\n";	// Saves car Name and Driver
				}

				tempStr = currNode->PrintPassenger();	// Gets passenger info
				cout << tempStr;						// Prints passenger info
				allInfo += tempStr;						// Adds passenger info to output file

				currNode = currNode->GetNext();			// Iterate to next node
				err = "1"; 								// Negate error

			} else {
				currNode = currNode->GetNext();			// Iterate to next if not a match
			}
		}
		if (err == "0") {
			throw err;									// Throws error if no match is found
		}
	} catch (string& err) {
		cout << " *** Exception: Invalid car" << endl;
		return 0;
	}

	// *** Output File ***
	// Create name of file
	pos = userInput.find(" ");
	userInput.replace(pos, 1, "_");

	// Create file
	nameT = userInput + ".txt";
	ofstream outfile (nameT);

	// Test if files is open
	if (!outfile.is_open()) {
		cout << " *** Could not open file" << endl;
		return 0;
	}

	// Input information into file
	allInfo.pop_back(); 	//removes last newline
	outfile << allInfo;

	// Close file
	outfile.close();

	return 0;
}

//COMPLETE
//password can and should be changed in here
 //Name: PrintReservations()
 //Input: two nodes
 //Output: txt file with reservation data
 //Purpose: Prints the complete list of Passengers and Vehicles as a .txt file
int Reservation::PrintReservations(SeatNode* headNode, SeatNode* lastNode) {
	string userInput, password = "9@$$w0R]", manifest, prevCar;
	SeatNode* currNode;

	// Prompt for password and get user input
	cout << endl << "Password required: ";
	cin >> userInput;

	// Quit if password is incorrect
	if (userInput != password) {
		cout << " *** Incorrect password" << endl;
		return 0;
	}

	// *** Create data to input to .txt file ***
	// Reset currNode to the first node
	currNode = headNode->GetNext();

	// Add first Car and Driver to manifest
	manifest = currNode->GetCar() + "\n" + "   DRIVER: " + currNode->GetDriver().GetName() + "\n";
	// Save car name to compare to next car Name
	prevCar = currNode->GetCar();

	do {
		// If currNode has a different Car value then the previous, add new Car and Driver to Manifest
		if (prevCar != currNode->GetCar()) {
			manifest += "\n" + currNode->GetCar() + "\n" + "   DRIVER: " + currNode->GetDriver().GetName() + "\n";	// Save car Name and Driver
			prevCar = currNode->GetCar();																			// Reset prevCar value
		}

		manifest += "   " + currNode->PrintPassenger();		// Adds seat Type and Passenger to manifest
		currNode = currNode->GetNext();						// Iterates to next node

	} while (currNode != nullptr);

	// *** Output File ***
	// Create file
	ofstream outfile ("all_reservations.txt");
	cout << "File \"all_reservations.txt\" created" << endl;

	// Test if files is open
	if (!outfile.is_open()) {
		cout << " *** Could not open file" << endl;
		return 0;
	}

	// Input information into file
	manifest.pop_back(); 	//removes last newline
	outfile << manifest;

	// Close file
	outfile.close();

	return 0;
}





