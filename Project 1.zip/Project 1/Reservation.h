/****
 * Title: Project 1 Reservation System
 * Course: Computational Problem Solving II (CPET-321.01.2211)
 * Developer: Elyse Amorati
 * Date: Oct 8, 2021
 * Description: [Reservation.h]Using supporting files, forms a reservation system for quidditch team
 ***/

#ifndef RESERVATION_H_
#define RESERVATION_H_

#include "Passenger.h"
#include "SeatNode.h"
#include <string>
#include <vector>

class Reservation {
public:
	string ToUpper(string s);

	char PrintMenu();

	// Altering the linked list and databases
	int CreateReservations(vector<Passenger>& passengers, SeatNode* headNode, SeatNode* lastNode);
	int ModifyReservations(vector<Passenger>& passengers, SeatNode* headNode, SeatNode* lastNode);
	int DeleteReservations(vector<Passenger>& passengers, SeatNode* headNode, SeatNode* lastNode);

	// Display and Print
	int DisplayVehicles(SeatNode* headNode, SeatNode* lastNode);
	int PrintVehicles(SeatNode* headNode, SeatNode* lastNode);
	int PrintReservations(SeatNode* headNode, SeatNode* lastNode);

};

#endif /* RESERVATION_H_ */
