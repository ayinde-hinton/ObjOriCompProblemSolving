/****
 * Title: Project 1 Reservation System
 * Course: Computational Problem Solving II (CPET-321.01.2211)
 * Developer: Elyse Amorati
 * Date: Oct 8, 2021
 * Description: [Passenger.cpp]Using supporting files, forms a reservation system for quidditch team
 ***/


#include "Passenger.h"
#include <iostream>
using namespace std;

 //Name: Passenger()
 //Input: n/a
 //Output: generic passenger object
 //Purpose: Generic constructor
Passenger::Passenger() {
	name = "";
	credit = -1;
	index = "-1";
}

 //Name: Passenger()
 //Input: (2)first and last name strings
 //Output: (1) passenger object with first and last name
 //Purpose: Creates Driver, assigns Name
Passenger::Passenger(string f, string l) {
	name = f + " " + l;
	credit = -1;
	index = "-1";
}

 //Name: Passenger()
 //Input: (4)first and last name strings token and position integers
 //???
 //Output: (1) passenger object with first and last name token count and position in linked list
 //Purpose: Creates Passenger, assigns Name, Credit, and Index
Passenger::Passenger(string f, string l, int c, int i) {
	name = f + " " + l;
	credit = c;
	if (i < 10) {
		index = "0" + to_string(i);
	} else {
		index = to_string(i);
	}
}

 //Name: GetName()
 //Input: n/a
 //Output: name
 //Purpose: returns passenger Name
string Passenger::GetName() {
	return name;
}

 //Name: GetCredits()
 //Input: n/a
 //Output: credit
 //Purpose: Returns remaining Credit
int Passenger::GetCredits() {
	return credit;
}

 //Name: GetIndex()
 //Input: n/a
 //Output: index
 //Purpose: Returns Index value
string Passenger::GetIndex() {
	return index;
}

 //Name: SetCredits()
 //Input: tokens
 //Output: n/a
 //Purpose: Resets Credits value
void Passenger::SetCredits(int t) {
	credit = t;
}

 //Name: Print()
 //Input: n/a
 //Output: passenger Name and remaining Credits
 //Purpose: Prints passenger Name and remaining Credits
void Passenger::Print() {
	cout << name << ": " << credit << endl;
}



