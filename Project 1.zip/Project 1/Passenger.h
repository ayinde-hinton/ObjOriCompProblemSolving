/****
 * Title: Project 1 Reservation System
 * Course: Computational Problem Solving II (CPET-321.01.2211)
 * Developer: Elyse Amorati
 * Date: Oct 8, 2021
 * Description: [Passenger.h]Using supporting files, forms a reservation system for quidditch team
 ***/

#ifndef PASSENGER_H_
#define PASSENGER_H_

#include <string>
using namespace std;

class Passenger {
	public:
		// Constructors
		Passenger();
		Passenger(string f, string l);
		Passenger(string f, string l, int t, int i);

		// Get functions
		string GetName();
		string GetIndex();
		int GetCredits();

		// Set function
		void SetCredits(int t);

		// Print function that should get deleted?
		void Print();

	private:
		string name, index;
		int credit;
};

#endif /* PASSENGER_H_ */
