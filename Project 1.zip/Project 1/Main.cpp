/****
 * Title: Project 1 Reservation System
 * Course: Computational Problem Solving II (CPET-321.01.2211)
 * Developer: Elyse Amorati
 * Date: Oct 8, 2021
 * Description: [Main.cpp]Using supporting files, forms a reservation system for quidditch team
 ***/
 

#include <fstream>
#include <vector>
#include <iostream>

#include "Reservation.h"
#include "SeatNode.h"
using namespace std;

//Name: ReadDrivers()
//Input: (2) one string vectors, one ifstream
//Output: (0) void
//Purpose: Reads in the drivers into drivers vector
void ReadDrivers(vector<Passenger>& drivers, ifstream& inFS) {
	// Read in drivers as passenger objects from the file
	for (unsigned int i = 0; i < 8; i++) {
		string tempFirst, tempLast;
		inFS >> tempFirst >> tempLast;
		Passenger temp(tempFirst, tempLast);
		drivers.push_back(temp);
	}
}

//Name: ReadPassengers()
//Input: (2) one string vectors, one ifstream
//Output: (0) void
//Purpose: Reads in passengers into passengers vector
void ReadPassengers(vector<Passenger>& passengers, ifstream& inFS) {
	// Read in drivers as passenger objects from the file
	for (unsigned int i = 8; i < 31; i++) {
		string tempFirst, tempLast;
		int tempTokens;
		inFS >> tempFirst >> tempLast >> tempTokens;
		Passenger temp(tempFirst, tempLast, tempTokens, i-7);
		passengers.push_back(temp);
	}
}


 //Name: AssignSeats()
 //Input: (7) two node pointers, two string vectors, one int vector, one class vector, and one integer 
 //Output: (1) sets up fleet
 //Purpose: Actually creates new SeatNodes with correct info to add the linked list
void AssignSeats(SeatNode* headNode, SeatNode* lastNode, vector<string> cars, vector<string> seats, vector<int> costs, vector<Passenger>& drivers, int loc) {
	long unsigned int i, j;
	SeatNode* currSeat;

	// Loops through Cars and gets the associated Driver
	// Loops through each seat Type and creates a new node that is inserted at the end of the linked list
	//       Node includes the car (color & type), seat type, cost of seat, and driver

	for (i = 0; i < cars.size(); i++) {
		Passenger d = drivers.at(loc);
		for (j = 0; j < seats.size(); j++) {
	      currSeat = new SeatNode(cars.at(i), seats.at(j), costs.at(j), d);

	      lastNode->InsertAfter(currSeat);
	      lastNode = currSeat;
	   }
		loc++;
	}
}

 //Name: CreateSeats()
 //Input: (3) one vector for drivers and two node pointers
 //Output: (3) linked list of potential car seats
 //Purpose: Contains all necessary info to Create Seats, calls AssignSeats
void CreateSeats(vector<Passenger>& drivers, SeatNode* headNode, SeatNode* lastNode) {
   // Create storage of all cars
   vector<string> pickups{"PURPLE PICKUP", "GREEN PICKUP"};
   vector<string> compacts{"RED COMPACT", "BLUE COMPACT", "YELLOW COMPACT"};
   vector<string> sedans{"BLUE SEDAN", "BLACK SEDAN", "GREEN SEDAN"};

   // Create storage for all seat types and their associated cost
   vector<string> pickupSeats{"FRONT"};
   vector<int> pickupCost{5};
   vector<string> compactSeats{"FRONT", "BACK", "BACK"};
   vector<int> compactCost{5, 3, 3};
   vector<string> sedanSeats{"FRONT", "BACK", "MID", "BACK"};
   vector<int> sedanCost{5, 2, 1, 2};

   // Add all seats to the linked list
   //     each seat contains the type, the driver, and the cost
   AssignSeats(headNode, lastNode, sedans, sedanSeats, sedanCost, drivers, 5);
   AssignSeats(headNode, lastNode, compacts, compactSeats, compactCost, drivers, 2);
   AssignSeats(headNode, lastNode, pickups, pickupSeats, pickupCost, drivers, 0);
}


int main (int argc, char* argv[]) {
   // References for SeatNode objects
   SeatNode* headNode;
   SeatNode* lastNode;

   // Creates file stream
   ifstream inFS;

   // Variable declarations
   char exit;
   vector<Passenger> drivers;
   vector<Passenger> passengers;

   // Front of nodes list
   headNode = new SeatNode();
   lastNode = headNode;

   // Try to open file
   inFS.open("quidditch.dat");
   if (!inFS.is_open()) {
	   cout << "Could not open file quidditch.dat." << endl;
   	   return 1; // 1 indicates error
   }

   // Read in drivers and passengers into the according vectors
   ReadDrivers(drivers, inFS);
   ReadPassengers(passengers, inFS);

   // Close file
   inFS.close();

   // Create seats for all cars
   CreateSeats(drivers, headNode, lastNode);

   // Create Reservation to access all actions
   Reservation menu;

   // Output menu, get user input
   exit = menu.PrintMenu();
   while (exit != '0') {
	   switch (exit) {
	   	   case '1':
	   		   // Create a reservation
	   		   menu.CreateReservations(passengers, headNode, lastNode);
	   		   break;
	   	   case '2':
	   		   // Modify a reservation
	   		   menu.ModifyReservations(passengers, headNode, lastNode);
	   		   break;
	   	   case '3':
	   		   // Delete a reservation
	   		   menu.DeleteReservations(passengers, headNode, lastNode);
	   		   break;
	   	   case '4':
	   		   // Display vehicles
	   		   menu.DisplayVehicles(headNode, lastNode);
	   		   break;
	   	   case '5':
	   		   // Print vehicles
	   		   menu.PrintVehicles(headNode, lastNode);
	   		   break;
	   	   case '6':
	   		   // Print reservations
	   		   menu.PrintReservations(headNode, lastNode);
	   		   break;
	   	   default:
	   		   //  Invalid char was input
	   		   cout << " *** Invalid input" << endl;
	   }
	   cout << endl;
	   exit = menu.PrintMenu();
   }

   // SeatNode Destructor deletes all nodes
   delete headNode;
}
