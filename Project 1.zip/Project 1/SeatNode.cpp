/****
 * Title: Project 1 Reservation System
 * Course: Computational Problem Solving II (CPET-321.01.2211)
 * Developer: Elyse Amorati
 * Date: Oct 8, 2021
 * Description: [SeatNode.cpp]Using supporting files, forms a reservation system for quidditch team
 ***/


#include "SeatNode.h"
#include <iostream>
using namespace std;

 //Name: SeatNode()
 //Input: n/a
 //Output: node for a seat
 //Purpose: Generic constructor
SeatNode::SeatNode() {
   type = "";
   car = "";
   cost = -1;
   nextNodePtr = nullptr;
}

 //Name: ~SeatNode()
 //Input: n/a
 //Output: reallocated memore of former node
 //Purpose: Destructor
SeatNode::~SeatNode() {
   if(nextNodePtr != nullptr) {
      delete nextNodePtr;
   }
}

 //Name: SeatNode()
 //Input: two strings an int and a Passenger object
 //Output: linked list creation for holding seat reservations at each node
 //Purpose: Constructor that sets Car, Type, Cost, and Driver
SeatNode::SeatNode(string c, string t, int co, Passenger d) {
   car = c;
   type = t;
   cost = co;
   driver = d;
   nextNodePtr = nullptr;
}

 //Name: GetCar()
 //Input: n/a
 //Output: car object
 //Purpose: Returns Car
string SeatNode::GetCar() {
   return car;
}

 //Name: GetType()
 //Input: n/a
 //Output: type string
 //Purpose: Returns Type
string SeatNode::GetType() {
   return type;
}

 //Name: isTaken()
 //Input: n/a
 //Output: taken string
 //Purpose: Returns Taken
string SeatNode::isTaken() {
   return taken;
}

 //Name: GetReservation()
 //Input: n/a
 //Output: reservation int
 //Purpose: Returns Reservation number
string SeatNode::GetReservation() {
	return reservation;
}

 //Name: GetPassenger()
 //Input: n/a
 //Output: passenger object
 //Purpose: Returns Passenger
Passenger SeatNode::GetPassenger() {
	return p;
}

 //Name: GetDriver()
 //Input: n/a
 //Output: driver string
 //Purpose: Returns Driver
Passenger SeatNode::GetDriver() {
	return driver;
}

 //Name: GetCost()
 //Input: n/a
 //Output: cost string
 //Purpose: Returns Cost
int SeatNode::GetCost() {
   return cost;
}

 //Name: AssignSeat() 
 //Input: one Passenger object and one string r
 //Output: seat marked for passenger's name
 //Purpose: Assigns current SeatNode to be Taken by Passenger with Reservation Number
void SeatNode::AssignSeat(Passenger pass, string r) {
	p = pass;
	reservation = r;
	taken = "Taken";
}

 //Name: DeleteSeat()
 //Input: n/a
 //Output: resets a taken seat
 //Purpose: Wipes clean all information contained in current SeatNode
void SeatNode::DeleteSeat() {
	Passenger blank;
	p = blank;
	reservation = "";
	taken = "Unassigned";
}

 //Name: GetNext()
 //Input: n/a
 //Output: pointer to next node
 //Purpose: Get location pointed by nextNodePtr
SeatNode* SeatNode::GetNext() {
   return nextNodePtr;
}

 //Name: InsertAfter()
 //Input: node pointer
 //Output: new node in linked list
 //Purpose: Adds node to the end of linked list
void SeatNode::InsertAfter(SeatNode* nodeLoc) {
	SeatNode* tmpNext;

   tmpNext = nextNodePtr;
   nextNodePtr = nodeLoc;
   nodeLoc->nextNodePtr = tmpNext;
}

 //Name: PrintPassenger()
 //Input: n/a
 //Output: prints reservation holder's name
 //Purpose: Returns Seat type: passenger Name or Unassigned to be printed
string SeatNode::PrintPassenger() {
	string out;
	if (taken == "Taken") {
		out = type + ": " + p.GetName() + "\n";
	} else {
		out = type + ": Unassigned" + "\n";
	}
	return out;
}

 //Name: PrintContactNode()
 //Input: n/a
 //Output: outputs all the reservation/node information
 //Purpose: Print Node THAT WILL GET DELETED
void SeatNode::PrintContactNode(){
   cout << "Car: " << car << endl;
   cout << "Seat type: " << type << endl;
   cout << "Cost: " << cost << endl;
   cout << "Taken: " << taken << endl;
   cout << "Passenger: " << p.GetName() << endl;
   cout << "Reservation: " << reservation << endl;
   cout << "Driver: " << driver.GetName() << endl;
}



