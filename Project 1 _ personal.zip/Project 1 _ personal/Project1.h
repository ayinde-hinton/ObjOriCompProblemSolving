/*
 * Project1.h
 *
 *  Created on: Oct 8, 2021
 *      Author: anh1213
 */

#ifndef PROJECT1_H_
#define PROJECT1_H_

#include <iostream>
#include <fstream>
using namespace std;
// Tasks/Notes
// Create two loops
//  an 8 step loop for drivers
//  a 23 step loop for passengers
// reference 7.3 for how to set up loop contents
//Reading in files
   ifstream quidditch;     // Input file stream

   //vector<string> driver(7);
   //vector<string> passenger(22);
   //vector<int> token;

   cout << "Opening file quidditch.dat" << endl;

   quidditch.open("quidditch.dat");
   //assuming we can change the file to have list length at the top
   //int size;
   //quidditch >> size;
   //team.resize(size)
   if (!quidditch.is_open()){
	   cout << "Could not open file quidditch.dat" << endl;
	   return 1; // indicates error
   }

   cout << "Reading in Initial Player List" << endl;
   for (int i = 0; i < driver.size(); ++i){
	   inFile >> firstName >> lastName ;
	   driverName = firstName + " " + lastName;
	   driver.at(i) = driverName;
   }
   for (int i = 0; i < passenger.size(; ++i)){
	   inFile >> firstName >> lastName >> wallet;
	   passengerName = firstName + " " + lastName;
	   token.at(i) = wallet;
	   driver.at(i) = driverName;
   }

   cout << "Closing file quidditch.dat" << endl;
   quidditch.close()

//Defining functions
// use name and token to form node in linked list
//Main
	int main(){
	//
	return 0;
   }

#endif /* PROJECT1_H_ */