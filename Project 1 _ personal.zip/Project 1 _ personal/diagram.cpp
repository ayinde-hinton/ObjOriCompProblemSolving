
// *** Create data to input to .txt file ***
	// Reset currNode to the first node
	currNode = headNode->GetNext();

	// Add first Car and Driver to manifest
	manifest = currNode->GetCar() + "\n" + "   DRIVER: " + currNode->GetDriver().GetName() + "\n";
	// Save car name to compare to next car Name
	prevCar = currNode->GetCar();

	do {
		// If currNode has a different Car value then the previous, add new Car and Driver to Manifest
		if (prevCar != currNode->GetCar()) {
			manifest += "\n" + currNode->GetCar() + "\n" + "   DRIVER: " + currNode->GetDriver().GetName();	// Save car Name and Driver
			prevCar = currNode->GetCar();																			// Reset prevCar value
		}

		manifest += "   " + currNode->GetType();		// Adds seat Type and Passenger to manifest
		currNode = currNode->GetNext();						// Iterates to next node

	} while (currNode != nullptr);

	// *** Output File ***
	// Create file
	ofstream outfile ("all_reservations.txt");
	cout << "File \"all_reservations.txt\" created" << endl;

	// Test if files is open
	if (!outfile.is_open()) {
		cout << " *** Could not open file" << endl;
		return 0;
	}

	// Input information into file
	manifest.pop_back(); 	//removes last newline
	outfile << manifest;

	// Close file
	outfile.close();

	return 0;
	
//
manifest = "\n" + currNode->GetCar() + "\n";
	do {
		// If currNode has a different Car value then the previous, add new Car and Driver to Manifest
		if (prevCar != currNode->GetCar()) {
			manifest = "\n" + currNode->GetCar() + "\n"  + "   Seat: " + currNode->GetType();
			prevCar = currNode->GetCar(); //??? Reset prevCar value
		}
		manifest += "   " + currNode->GetType();		// Adds seat Type and Passenger to manifest
		currNode = currNode->GetNext();					// Iterates to next node
		} while (currNode != nullptr);